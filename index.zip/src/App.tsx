/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Music, Volume2, VolumeX, Sparkles, ChevronRight, MessageCircleHeart, Bird, Star } from 'lucide-react';

const HeartParticles = () => {
  const [particles, setParticles] = useState<{ id: number; left: string; size: number; duration: number; delay: number }[]>([]);

  useEffect(() => {
    const newParticles = Array.from({ length: 20 }).map((_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      size: Math.random() * 20 + 10,
      duration: Math.random() * 5 + 5,
      delay: Math.random() * 5,
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
      {particles.map((p) => (
        <div
          key={p.id}
          className="heart-particle text-red-500/20"
          style={{
            left: p.left,
            fontSize: `${p.size}px`,
            animationDuration: `${p.duration}s`,
            animationDelay: `${p.delay}s`,
            bottom: '-50px',
          }}
        >
          <Heart fill="currentColor" />
        </div>
      ))}
    </div>
  );
};

const Section = ({ children, className = "" }: { children: React.ReactNode; className?: string; key?: string }) => (
  <motion.section
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    transition={{ duration: 0.8 }}
    className={`min-h-screen flex flex-col items-center justify-center p-6 relative z-10 ${className}`}
  >
    {children}
  </motion.section>
);

export default function App() {
  const [step, setStep] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const toggleMusic = () => {
    if (audioRef.current) {
      if (isMuted) {
        audioRef.current.play().catch(e => console.log("Audio play failed:", e));
      } else {
        audioRef.current.pause();
      }
      setIsMuted(!isMuted);
    }
  };

  const nextStep = () => setStep(s => s + 1);

  return (
    <div className="bg-gradient-romantic min-h-screen font-sans selection:bg-red-500/30">
      <HeartParticles />
      
      {/* Audio Element - Placeholder romantic track */}
      <audio 
        ref={audioRef} 
        loop 
        src="https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" 
      />

      {/* Music Toggle */}
      <button 
        onClick={toggleMusic}
        className="fixed top-6 right-6 z-50 p-3 rounded-full glass hover:bg-white/10 transition-all duration-300 group"
      >
        {isMuted ? (
          <VolumeX className="w-6 h-6 text-white/60 group-hover:text-white" />
        ) : (
          <Volume2 className="w-6 h-6 text-red-400 animate-pulse" />
        )}
      </button>

      <AnimatePresence mode="wait">
        {step === 0 && (
          <Section key="landing" className="text-center">
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="relative"
            >
              <div className="absolute -inset-10 bg-red-600/20 blur-3xl rounded-full animate-pulse" />
              <h1 className="font-serif text-7xl md:text-9xl mb-4 tracking-tighter text-glow">
                እርግቤ
              </h1>
              <p className="font-serif italic text-xl md:text-2xl text-white/60 mb-12 tracking-widest uppercase">
                My Dove • My Everything
              </p>
            </motion.div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={nextStep}
              className="px-8 py-4 rounded-full glass flex items-center gap-3 text-lg font-medium group hover:border-red-500/50 transition-all"
            >
              Begin Our Journey
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </Section>
        )}

        {step === 1 && (
          <Section key="letter" className="max-w-3xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass p-8 md:p-12 rounded-3xl relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent" />
              
              <Bird className="w-12 h-12 text-red-400 mx-auto mb-8 animate-bounce" />
              
              <h2 className="font-serif text-4xl md:text-5xl mb-8 text-white/90">
                To My Dearest...
              </h2>
              
              <div className="space-y-6 text-lg md:text-xl text-white/70 leading-relaxed font-light">
                <p>
                  In a world full of noise, you are my favorite melody. 
                  Every moment with you feels like a beautiful dream I never want to wake up from.
                </p>
                <p>
                  You are the "እርግቤ" (Dove) that brought peace to my heart. 
                  Your smile is my sunrise, and your love is my sanctuary.
                </p>
                <p className="font-serif italic text-2xl text-red-400 mt-8">
                  "ካንቺ በላይ ለኔ ማንም የለም..."
                </p>
              </div>

              <motion.button
                onClick={nextStep}
                className="mt-12 px-8 py-3 rounded-full bg-red-600 hover:bg-red-500 text-white font-medium transition-colors shadow-lg shadow-red-900/20"
              >
                Continue
              </motion.button>
            </motion.div>
          </Section>
        )}

        {step === 2 && (
          <Section key="gallery" className="w-full">
            <h2 className="font-serif text-5xl md:text-7xl mb-16 text-center text-glow">
              Why You?
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl w-full px-4">
              {[
                { icon: <Sparkles />, title: "Your Soul", desc: "A light that guides me through the darkest nights." },
                { icon: <MessageCircleHeart />, title: "Your Voice", desc: "The only sound that makes my heart skip a beat." },
                { icon: <Star />, title: "Your Future", desc: "The only one I see by my side, forever." }
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.2 }}
                  className="glass p-8 rounded-2xl hover:bg-white/5 transition-colors group"
                >
                  <div className="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center mb-6 text-red-400 group-hover:scale-110 transition-transform">
                    {item.icon}
                  </div>
                  <h3 className="text-2xl font-serif mb-4">{item.title}</h3>
                  <p className="text-white/60 leading-relaxed">{item.desc}</p>
                </motion.div>
              ))}
            </div>

            <motion.button
              onClick={nextStep}
              className="mt-20 px-10 py-4 rounded-full glass border-red-500/30 hover:bg-red-500/10 transition-all"
            >
              The Final Question
            </motion.button>
          </Section>
        )}

        {step === 3 && (
          <Section key="final" className="text-center">
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ type: "spring", damping: 12 }}
            >
              <Heart className="w-24 h-24 text-red-500 mx-auto mb-8 animate-pulse fill-current" />
              <h2 className="font-serif text-6xl md:text-8xl mb-6">I Love You</h2>
              <p className="text-2xl text-white/50 mb-12 font-light">Will you be my forever?</p>
              
              <div className="flex flex-wrap justify-center gap-6">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => alert("My heart is yours! ❤️")}
                  className="px-12 py-4 rounded-full bg-red-600 text-white text-xl font-bold shadow-xl shadow-red-900/40"
                >
                  Yes, Always
                </motion.button>
                
                <motion.button
                  onMouseEnter={(e) => {
                    const btn = e.currentTarget;
                    btn.style.position = 'absolute';
                    btn.style.left = `${Math.random() * 80 + 10}%`;
                    btn.style.top = `${Math.random() * 80 + 10}%`;
                  }}
                  className="px-12 py-4 rounded-full glass text-white/40 text-xl cursor-default transition-all duration-100"
                >
                  No
                </motion.button>
              </div>
            </motion.div>

            <p className="fixed bottom-10 left-0 w-full text-center text-white/20 text-sm tracking-widest uppercase">
              Dedicated to my one and only እርግቤ
            </p>
          </Section>
        )}
      </AnimatePresence>

      {/* Progress Indicator */}
      <div className="fixed bottom-6 right-6 flex gap-2 z-50">
        {[0, 1, 2, 3].map((i) => (
          <div 
            key={i}
            className={`h-1 transition-all duration-500 rounded-full ${step === i ? 'w-8 bg-red-500' : 'w-2 bg-white/20'}`}
          />
        ))}
      </div>
    </div>
  );
}
